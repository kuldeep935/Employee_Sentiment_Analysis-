# Employee Sentiment Analysis

## Project Overview
This project analyzes employee email communications to evaluate sentiment, engagement, and potential flight risk.

## Methodology
- Sentiment labeling using TextBlob polarity
- Monthly sentiment score calculation (+1, -1, 0)
- Employee ranking by monthly score
- Flight risk detection using rolling 30-day negative message count
- Linear regression modeling for sentiment trends

## Setup Instructions
1. Clone the repository
2. Install dependencies:
   pip install -r requirements.txt
3. Place test.csv inside data folder
4. Run Employee_Sentiment_Analysis.ipynb

## Flight Risk Criteria
An employee is considered at flight risk if they send 4 or more negative messages within a rolling 30-day period.

## Key Findings
- Sentiment distribution shows majority neutral communication
- Certain employees consistently rank highly positive
- 9 employees identified as flight risk
- Regression model provides moderate prediction of sentiment trends